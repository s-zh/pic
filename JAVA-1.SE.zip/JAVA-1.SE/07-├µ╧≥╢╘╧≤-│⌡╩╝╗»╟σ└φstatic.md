## static 修饰符

**静态代码块：**

执行优先级高于非静态的初始化块，它会在类初始化的时候执行一次，执行完成便销毁，它仅能初始化类变量，即static修饰的数据成员。 

**静态变量：**

static 关键字用来声明独立于对象的静态变量，无论一个类实例化多少对象，它的静态变量只有一份拷贝。 静态变量也被称为类变量。局部变量不能被声明为 static 变量。

**静态方法：**

static 关键字用来声明独立于对象的静态方法。静态方法不能使用类的非静态变量。静态方法从参数列表得到数据，然后计算这些数据。

```java
public class Bank {
    //静态代码块
    static{
        System.out.println("银行类");
    }
    
    //定义一个私有的静态的变量
    private static double money = 0;

    //定义一个受保护权限的获取钱的方法
    protected static double getMoney(){
        return money;
    }

    //定义一个私有的存钱的方法
    private static void addMoney(){
        money += 100;
    }

    //默认权限的构造方法
    Bank(){
        //调用存钱的方法
        Bank.addMoney();
    }

    public static void main(String[] args) {
        System.out.println("Starting with " + Bank.getMoney() + " instances");

        //调用存钱的方法
        for(int i=0; i<100; i++){
            new Bank();
        }

        System.out.println("Created " + Bank.getMoney() + " instances");
    }
}
```

**static的访问特点：**

```java
public class Bank {
    //静态代码块
    static{
        System.out.println("银行类");
    }
    
    //定义一个私有的静态的变量
    private static double money = 0;

    //定义一个非静态私有的变量
    private String bankName = "中国银行";

    //定义一个受保护权限的获取钱的方法
    protected static double getMoney(){
        return money;
    }

    //定义一个私有的存钱的方法
    private static void addMoney(){
        money += 100;
    }

    //默认权限的构造方法
    Bank(){
        //调用存钱的方法
        Bank.addMoney();
    }

    //定义一个非静态的取钱的方法
    public void reduceMoney(){
        money -= 100;
    }

    //获取银行名称的非静态方法
    public String getBankName(){
        //能访问静态的成员变量
        System.out.println("非静态方法调用静态变量："+money);
        //能访问非静态的成员变量
        System.out.println("非静态方法调用非静态变量："+bankName);
        //能访问静态的成员方法
        addMoney();
        System.out.println("非静态方法调用静态方法："+getMoney());
        //能访问非静态的成员方法
        reduceMoney();
        System.out.println("非静态方法调用非静态方法："+getMoney());
        return bankName;
    }

    public static void main(String[] args) {
        //调用非静态属性
        //String bankName = Bank.bankName; //调用不了静态属性
        String bankName = new Bank().bankName;

        //调用非静态方法
        //Bank.getBankName();   //调用不了非静态的方法
        String name = new Bank().getBankName();
        System.out.println(name);
    }
}
```

* 非静态的成员方法
  * 能访问静态的成员变量
  * 能访问非静态的成员变量
  * 能访问静态的成员方法
  * 能访问非静态的成员方法
* 静态的成员方法
  * 能访问静态的成员变量
  * 能访问静态的成员方法
* 总结成一句话就是：
  * **静态成员方法只能访问静态成员**

## 初始化

初始化和清理是程序设计安全性的两个最重要的问题。 
C++为我们引入了构造函数的概念，Java也沿用了这个概念，但新增了自己的垃圾收集器。
构造函数可以理解为初始化函数。

### 成员初始化

类的成员变量有默认值(局部变量没有默认值)。
由于任何方法都可以初始化或使用成员变量数据，所以在正式使用数据前，若还是强迫程序员将其一一初始化成一个适当的值，就可能不够实际。因此，一个类的所有数据成员都会保证获得一个确定的值。在没有赋值之前有默认值。
简单类型为原始值（区分数据类型）。
引用变量默认值null。

```java
//定义初始化：

//1.一个直接的做法是在定义数据成员的同时也为其赋值。
class Measurement { 
	boolean b=true;
	char c='x';
	int i=47;
};

//2.也可以用相同的方法初始化对象，并给引用变量赋值。 
class Measurement { 
	Depth o = new Depth(); //通过构造函数初始化对象
}; 

//3.还可以通过调用方法对成员变量进行初始化。
//简单的方法初始化
public static void main(String[] args){
    int i = f(); // f()需要返回一个int类型值
}
public static int f(){
    return 5;
}
//方法也可以使用参数
int i = f(); 
int k = g(i); // g()返回一个int类型值
//参数不能是尚未声明的其它数据成员。（如下编译通不过）
int j = g(i); // i 未声明
int i = f(); 

//构造代码块
{
     b = false;
     c = 'A';
     i = 666;
}
```

### 类的初始化

#### 类的生命周期

![-c](https://gitee.com/mrth4869/pic/raw/master/20210720062811.png)

(加载：查找并加载类的二进制数据.class
连接
		验证：确保加载的类的正确性
  	  准备：为类的静态变量分配内存，并将其初始化为默认值
   	 解析：把类中的符号引用转为直接引用
初始化：为类的静态变量赋予正确的初始值)

加载
通过一个类的全限定名来获取此类的二进制字节流。
将这个字节流所代表的静态存储结构转化为方法区的运行时数据结构。
在java堆中生成一个代表这个类的Class对象，作为方法区这些数据的访问入口。

验证
保Class文件的字节流中包含的信息符合当前虚拟机的要求，并且不会危害虚拟机自身的安全

准备
正式为类变量分配内存并设置类变量初始值(各数据类型的默认值)的阶段，这些内存将在方法区中进行分配。
但是如果类字段的字段属性表中存在常量属性，那在准备阶段变量值就会初始化为常量属性指定的值。

解析
在虚拟机将常量池内的符号引用替换为直接引用的过程。

#### 类的初始化

初始化
执行类构造器<clinit>()方法的过程。
<clinit>()方法是由编译器自动收集类中的所有类变量的赋值动作和静态语句块中的语句合并产生的，编译器收集的顺序是由语句在源文件中出现的顺序决定的。静态语句块只能访问到定义在静态语句块之前的变量，定义在它之后的变量，在前面的静态语句块中可以赋值，但是不能访问。

```java
public class Test3 {
    static{
        sex="male";   //可以赋值
        //System.out.println(sex);  //不可以访问到
    }
    
    public static String sex;

    static{
        sex="female";    //可以赋值
        System.out.println(sex);  //可以访问到
    }
}
```

#### 静态数据初始化

静态的东西属于**类**。 
类Class与类变量。
静态数据成员在第一次主动使用这个类的时候初始化。

在初始化阶段，java虚拟机执行类的初始化语句，为类的静态变量赋予初始值。
在程序中，静态变量的初始化有两种途径
（1）在静态变量的声明处进行初始化   直接赋值
（2）在静态代码块中进行初始化    static{}
遵循先声明后赋值原则

```java
public class Test3 {
    public static String name;
    public static String sex;

    static{
        System.out.println("静态代码块");
        //初始化数据
        name = "Nancy";
        sex = "female";
    }
    
    Test3(){
        System.out.println(name+"-->"+sex);
    }
}
```

### 类的初始化时机

类的生命周期的开始阶段--类装载又是在什么时候被触发呢？类又是何时被初始化的呢？

虚拟机类加载机制：虚拟机把描述类的数据从class文件加载到内存，并对数据进行校验、转换解析和初始化，最终形成可以被虚拟机直接使用的Java类型。

Java 虚拟机规范为类的初始化时机做了严格定义："initialize on first active use"--" 在首次主动使用时初始化"。

首次**主动使用**的情形：
创建某个类的新实例时--new、反射、克隆或反序列化；
调用某个类的静态方法时；
使用某个类或接口的静态字段或对该字段赋值时（final字段除外）；
调用Java的某些反射方法时；
初始化某个类的子类时；
在虚拟机启动时某个含有main()方法的那个启动类。

除了以上几种情形以外，所有其它使用JAVA类型的方式都是被动使用的，他们不会导致类的初始化。

### 对象初始化顺序

类型为Dog的一个对象首次创建时，或者Dog类的静态方法/数据首次访问时，Java解释器必须找到Dog.class。 
找到Dog.class后，它的所有的静态初始化模块都会运行。因此，静态初始化仅发生一次。 
创建一个new Dog( )时，new语句首先会在堆里分配一个足够的空间。 
Dog中所有的实例成员变量都得到了缺省值。 
通过=对成员变量进行初始化。
通过非静态代码块初始化 。
执行构造函数。 

```java
class Dog{
	private String name = "小黑";//通过=对成员变量进行初始化
    private String sex;
    private int age;
    
    //非静态代码块进行成员变量的初始化
    {
        this.sex = "male";
        this.age = 2;
    }
    
    public Dog(){}
    
}
```

### final属性的初始化

如果类的**属性为final的则只能赋值一次** 
可以在声明的时候直接赋值
可以在代码块中赋值
可以在构造方法中赋值，如果构造方法之间没有调用则必须在所有的构造方法中都进行初始化
上述初始化只能选择其中一种方式

```java
public class FinalTest1 {
     //-----------------成员变量------------------//
     //初始化方式一，在定义变量时直接赋值
     private final int i = 3; 
    
     //初始化方式二,声明完变量后在构造方法中为其赋值
     //如果采用用这种方式，那么每个构造方法中都要有j赋值的语句
     private final int j;
     public FinalTest1() {
         j = 3;
     } 
    
     //如果取消该构造方法的注释，程序就会报错，因此它没有为j赋值
     /*public FinalTest1(String str) {
     
     }*/
 
    //为了方便我们可以这样写
     public FinalTest1(String str) {
         this();
     }
 
     //下面的代码同样会报错，因为对j重复赋值
     /*public FinalTest1(String str1, String str2) {
         this();
         j = 3;//The final field j may already have been assigned
     }*/
  
     //初始化方式三，声明完变量后在构造代码块中为其赋值
     //如果采用此方式，就不能在构造方法中再次为其赋值
     //构造代码块中的代码会在构造函数之前执行，如果在构造函数中再次赋值，
     //就会造成final变量的重复赋值
     private final int k;
 
     {
         k = 4;
     }
 
    
     //-----------------类变量（静态变量）------------------//
     //初始化方式一，在定义类变量时直接赋值
     public final static int p = 3;
 
     //初始化方式二，在静态代码块中赋值
     //成员变量可以在构造函数中赋值，但是类变量却不可以。
     //因此成员变量属于对象独有，每个对象创建时只会调用一次构造函数，
     //因此可以保证该成员变量只被初始化一次；
     //而类变量是该类的所有对象共有，每个对象创建时都会对该变量赋值
     //这样就会造成变量的重复赋值。
     public final static int q;
 
     static {
         q = 3;
     }
 }
```

### 初始化的顺序

先静态，后非静态
	    先声明，后赋值
		先属性，后方法
		在一个类里，初始化的顺序是由变量在类内的定义顺序决定的。即使变量定义大量遍布于方法定义的中间，那些变量仍然会在调用任何方法之前得到初始化——在构造函数之前。

```java
/*
 * 口诀：
 * 先静态后非静态
 * 先属性后方法（构造方法）
 * 先声明后赋值 先按照顺序声明赋默认值 然后再按照顺序赋=后面的值
 * 先父类后子类
 * */
public class Person {  
	//成员变量
	int age=getI();
	String name;
	int i=10;
	
	//常量 的初始化
	//1.定义初始化 定义的地方直接赋值
	//2.构造方法初始化  每一个构造方法都要有赋值语句 或调用已经有赋值过程的其他构造方法
	final int NUMBER; 
	
	public int getI() {
		return i;// 0 --> 10
	}
	
	//构造方法
	public Person() {
		NUMBER=100;
	}
	
	public Person(int age,String name) {
		this();
		System.out.println("这是构造方法...");
		this.age=age;
		this.name=name;
		//NUMBER = 200;
	}
	
	//构造代码块
	{
		/*
		 * age=100; 
		 * name="李四";
		 */
		System.out.println("这是一个构造代码块...");
	}
	
	//静态变量
	static int x;
	
	//静态代码块
	static{
		System.out.println("我是静态代码块...");
	}
}
```

```java
//仅供参考学习：
//对于一个类而言，按照如下顺序执行：
//执行静态代码块
//执行构造代码块
//执行构造函数
//对于静态变量、静态初始化块、变量、初始化块、构造器，它们的初始化顺序依次是（静态变量、静态初始化块）>（变量、初始化块）>构造器。
public class Test2{
	public static int k=0;//0 0 1 2 3 4 5 6 7 8 9 10 11
	public static Test2 t1=new Test2("t1");//null 0x1111
	public static Test2 t2=new Test2("t2");//null 0x3333
	public static int i=print("i");//0 1 2 3 4 5 6 7 8 9 10 11
	public static int n=99;//0 1  2 3 4 5 6 7 99 100  101 102 103
	//成员变量
	private int a=0;//0 0
					//0 0
					//0 0
	public int j=print("j");//0 1	
							//0 4
							//0 9
	static{
		print("静态块");
	}
	{
		print("构造块");
	}
	public Test2(String str){//t1 t2 init
		System.out.println((++k)+":"+str+"   i="+i+"   n="+n);
		++i;
		++n;
	}
	private static int print(String str){//j 构造块 j 构造块  i  静态块  j  构造块
		System.out.println((++k)+":"+str+"   i="+i+"   n="+n);
		++n;
		return ++i;
	}
	public static void main(String[] args) {
		Test2 t=new Test2("init");
	}
}
```

![-c](https://gitee.com/mrth4869/pic/raw/master/20210720062826.png)

## 清理

垃圾收集机制只知道怎样释放由new分配的内存，所以它不知道如何释放对象的 “特殊”内存。 一旦垃圾收集机制准备好释放对象占用的存储空间，它首先调用finalize()。
但是finalize()和C++的析构函数截然不同。 
垃圾收集不等于析构 
对象可能不会被当作垃圾被收集掉。 
垃圾收集只跟内存有关。

```java
public class Student {
	@Override
	protected void finalize() throws Throwable {
		super.finalize();
		System.out.println("jvm来回收垃圾啦...."+this);
	}
}

public class Test {
	public static void main(String[] args) {
		/*
		 * Object obj=new Object();// 0x1111 obj=null;
		 */
		
		//jvm回收垃圾：jvm空闲或者内存快要满的时候会来回收垃圾
		//通知机制：通知jvm来回收垃圾  gc()
		Student stu=new Student();
		System.out.println(stu);
//		Student stu2=stu;
		stu=null;
		System.gc();// 通知的方法
	}
}
```

