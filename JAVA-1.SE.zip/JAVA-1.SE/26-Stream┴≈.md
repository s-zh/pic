网站：https://www.runoob.com/java/java8-streams.html

stream介绍网站：https://blog.csdn.net/chenhao_c_h/article/details/80691284?utm_medium=distribute.pc_relevant_t0.none-task-blog-2%7Edefault%7EBlogCommendFromMachineLearnPai2%7Edefault-1.control&depth_1-utm_source=distribute.pc_relevant_t0.none-task-blog-2%7Edefault%7EBlogCommendFromMachineLearnPai2%7Edefault-1.control

## 一、Stream流

#### 1.什么是Stream

Java8 中，Collection 新增了两个流方法，分别是 stream() 和 parallelStream()。

Java8 中添加了一个新的接口 Stream，它可以通过 Lambda 表达式对集合进行大批量数据操作，或 者各种非常便利、高效的聚合数据操作。

#### 2.为什么要使用Stream

在 Java8 之前，我们通常是通过 for 循环或者 Iterator 迭代来重新排序合并数据，又或者通过重新定义 Collections.sorts 的 Comparator 方法来实现，这两种方式对于大数据量系统来说，效率并不是很理想。Stream 的聚合操作与数据库 SQL 的聚合操作 sorted、filter、map 等类似。我们在应用层就可以高效地实现类似数据库 SQL 的 聚合操作了，而在数据操作方面，Stream 不仅可以通过串行的方式实现数据操作，还可以通过并行的方式处理大批量数据，提高数据 的处理效率。

示例代码一：

```java
/*filter过滤操作        
 Stream<T> filter(Predicate<? super T> predicate);        
 
 函数式接口        
 Predicate - 判断型        
 Comparator        
 Consumer - 消费型         
*/        
/*        
第一步，将list转换为Stream，stream的数据元素是Integer, 这个是我们后面Predicate所使用的入参        
第二步，调用filter方法，使用Lambda,生成了一个Predicate的实现类，其中a是入参，是一个integer的数据类型  第三步，把过滤后的元素转换为一个新的集合        
注意：这里只是对管道中的流进行了操作，原来的集合是没有变化的         
*/
List<Integer> test = Arrays.asList(1,2,3,4,5,6,7,8,9);
List<Integer> collect = test.stream()
    .filter(a->a>1 && a<9)
    .collect(Collectors.toList());
System.out.println(collect);
System.out.println(test);
```

示例代码二：

```java
Map<Integer,String> map = new HashMap<>();
map.put(1,"hello");
map.put(2,"world");
map.put(3,"java");
Map<Integer,String> c = map.entrySet().stream()        
    .filter(a->a.getKey()==1)        
    .collect(Collectors.toMap(a->a.getKey(),a->a.getValue()));
System.out.println(c);
```

示例代码三：

```java
List<Integer> test = Arrays.asList(11,2,3,4,5,6,7,8,9,11);

//sorted排序
Integer i = test.stream()
    .sorted(Integer::compareTo)
    .findFirst().get();
System.out.println(i);

//倒序
List<Integer> list = test.stream()
     .sorted((a,b)->b-a)
     .collect(Collectors.toList());
System.out.println(list);

List<Integer> list = test.stream()
     .sorted(Comparator.comparing(a->-a))
     .collect(Collectors.toList());
System.out.println(list);

//map元素映射  接收一个方法作为参数，该函数会被应用到每个元素上，并将其映射成一个新的元素
List<Integer> list = test.stream()
    .sorted()
    .map(a->a*10)
    .collect(Collectors.toList());
System.out.println(list);

List<String> words = Arrays.asList("aaa", "vvvv", "cccc");
List<String> list = words.stream()
     .sorted()
     .map(a->a.toUpperCase())
     .collect(Collectors.toList());
System.out.println(list);

//distinct去重
List<Integer> list2 = test.stream()
    .sorted()
    .map(a->10*a)
    .distinct()
    .collect(Collectors.toList());
System.out.println(list2);

//使用collect()做字符串join
//使用Collectors.joining()拼接字符串
List<String> test1 = Arrays.asList("张三","李四","王五","赵六");
//String s = stream.collect(Collectors.joining()); // 张三李四王五赵六
//String s = stream.collect(Collectors.joining("-")); // 张三-李四-王五-赵六
String s = test1.stream().collect(Collectors.joining("-", "(", ")")); // (张三-李四-王五-赵六)
System.out.println(s);
```

## 二、list和map接口的foreach方法

示例代码

```java
//forEach遍历处理
/*
void forEach(Consumer<? super T> action);
入参是一个Consumer接口，他有两个方法void accept(T t)入参是流中的数据，然后调用覆盖的方法，覆盖数据元。
因为他是直接更改了流中的数据，也是最终操作，所以集合的元素是直接改变的 
*/

List<Integer> test = Arrays.asList(1,2,3,4,5,6,7,8,9);
test.forEach(System.out::println);

Map<Integer,String> map = new HashMap<>();
map.put(1,"hello");
map.put(2,"world");
map.put(3,"java");
map.forEach((k,v)-> System.out.println(k+"="+v));
```

## 三.案例需求

需求：先按照学生年龄倒序排序，在按照学生姓名倒序排序

```java
public class Test1 {
    public static void main(String[] args) {
        List<Student> test = Arrays.asList(
                new Student(14,"cc"),
                new Student(14,"aa"),
                new Student(10,"zz"),
                new Student(12,"dd"),
                new Student(16,"xx")
                );

		//sorted排序
        test.stream()           .sorted(Comparator.comparing(Student::getAge).reversed().thenComparing(Comparator.comparing(Student::getName).reversed()))
                .collect(Collectors.toList())
                .forEach(System.out::println);

    }
}

class Student{
    private int age;
    private String name;

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public Student(int age, String name) {
        this.age = age;
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return "Student{" +
               "age=" + age +
               ", name='" + name + '\'' +
               '}';
    }
}
```

