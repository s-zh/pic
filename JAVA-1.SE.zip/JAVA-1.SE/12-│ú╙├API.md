## 1. 常用API

==**自己查看各个类的源码**==

### 1.1 Math

* 1、Math类概述

  * Math 包含执行基本数字运算的方法

* 2、Math中方法的调用方式

  * **Math类中无构造方法，但==内部的方法都是静态的==**，==则可以通过   **类名.进行调用**==

* 3、Math类的常用方法

  | 方法名    方法名                                   | 说明                                           |
  | -------------------------------------------------- | ---------------------------------------------- |
  | public static int   **abs(int a)**                 | 返回参数的绝对值                               |
  | public static double **ceil(double a)**            | 返回大于或等于参数的最小double值，等于一个整数 |
  | public static double **floor(double a)**           | 返回小于或等于参数的最大double值，等于一个整数 |
  | public   static int **round(float a)**             | 按照四舍五入返回最接近参数的int                |
  | public static int   **max(int a,int b)**           | 返回两个int值中的较大值                        |
  | public   static int **min(int a,int b)**           | 返回两个int值中的较小值                        |
  | public   static double **pow (double a,double b)** | 返回a的b次幂的值                               |
  | public   static double **random()**                | 返回值为double的正值，**[0.0 , 1.0)**          |

### 1.2 System

* System类的常用方法 

| 方法名                                       | 说明                                             |
| -------------------------------------------- | ------------------------------------------------ |
| public   static void **exit(int status)**    | 终止当前运行的   Java   虚拟机，非零表示异常终止 |
| public   static long **currentTimeMillis()** | 返回当前时间(以毫秒为单位)                       |

* 示例代码

  * 需求：在控制台输出1-10000，计算这段代码执行了多少毫秒 

  ```java
  public class SystemDemo {
      public static void main(String[] args) {
          // 获取开始的时间节点
          long start = System.currentTimeMillis();
          for (int i = 1; i <= 10000; i++) {
              System.out.println(i);
          }
          // 获取代码运行结束后的时间节点
          long end = System.currentTimeMillis();
          System.out.println("共耗时：" + (end - start) + "毫秒");
      }
  }
  ```

### 1.3 Object类的==toString==方法

* Object类概述

  * **Object 是类层次结构的==根==**，**每个类都可以将 Object 作为==超类==**。所有类都直接或者间接的继承自该类，换句话说，**==该类所具备的方法，所有类都会有一份==**

* 查看方法源码的方式

  * 选中方法，按下Ctrl + B

* 重写toString方法的方式

  * 1. Alt + Insert 选择toString
  * 2. 在类的空白区域，右键 -> Generate -> 选择toString

*  toString方法的作用：

  * 以良好的格式，更方便的展示对象中的属性值

* 示例代码：

  ```java
  class Student extends Object {
      private String name;
      private int age;
  
      public Student() {
      }
  
      public Student(String name, int age) {
          this.name = name;
          this.age = age;
      }
  
      public String getName() {
          return name;
      }
  
      public void setName(String name) {
          this.name = name;
      }
  
      public int getAge() {
          return age;
      }
  
      public void setAge(int age) {
          this.age = age;
      }
  
      @Override
      public String toString() {
          return "Student{" +
                  "name='" + name + '\'' +
                  ", age=" + age +
                  '}';
      }
  }
  public class ObjectDemo {
      public static void main(String[] args) {
          Student s = new Student();
          s.setName("林青霞");
          s.setAge(30);
          System.out.println(s); 
          System.out.println(s.toString()); 
      }
  }
  ```

* 运行结果：

  ```java
  Student{name='林青霞', age=30}
  Student{name='林青霞', age=30}
  ```

### 1.4 Object类的==equals==方法

* equals方法的作用

  * 用于对象之间的比较，返回true和false的结果
  * 举例：s1.equals(s2);    s1和s2是两个对象

* 重写equals方法的场景

  * 不希望比较对象的地址值，想要结合对象属性进行比较的时候。

* 重写equals方法的方式

  * 1. alt + insert  选择equals() and hashCode()，IntelliJ Default，一路next，finish即可
  * 2. 在类的空白区域，右键 -> Generate -> 选择equals() and hashCode()，后面的同上。

* 示例代码：

  ```java
  class Student {
      private String name;
      private int age;
  
      public Student() {
      }
  
      public Student(String name, int age) {
          this.name = name;
          this.age = age;
      }
  
      public String getName() {
          return name;
      }
  
      public void setName(String name) {
          this.name = name;
      }
  
      public int getAge() {
          return age;
      }
  
      public void setAge(int age) {
          this.age = age;
      }
  
      @Override
      public boolean equals(Object o) {
          //this -- s1
          //o -- s2
          if (this == o) return true;
          if (o == null || getClass() != o.getClass()) return false;
  
          Student student = (Student) o; //student -- s2
  
          if (age != student.age) return false;
          return name != null ? name.equals(student.name) : student.name == null;
      }
  }
  public class ObjectDemo {
      public static void main(String[] args) {
          Student s1 = new Student();
          s1.setName("林青霞");
          s1.setAge(30);
  
          Student s2 = new Student();
          s2.setName("林青霞");
          s2.setAge(30);
  
          //需求：比较两个对象的内容是否相同
          System.out.println(s1.equals(s2));
      }
  }
  
  ```

### 1.5 冒泡排序原理

* 冒泡排序概述
  * 一种排序的方式，对要进行排序的数据中相邻的数据进行两两比较，将较大的数据放在后面，依次对所有的数据进行操作，直至所有数据按要求完成排序
* 如果有n个数据进行排序，总共需要比较n-1次
* 每一次比较完毕，下一次的比较就会少一个数据参与

### 1.6 冒泡排序代码实现

* 代码实现

```java
/*
    冒泡排序：
        一种排序的方式，对要进行排序的数据中相邻的数据进行两两比较，将较大的数据放在后面，
        依次对所有的数据进行操作，直至所有数据按要求完成排序
 */
public class ArrayDemo {
    public static void main(String[] args) {
        //定义一个数组
        int[] arr = {24, 69, 80, 57, 13};
        System.out.println("排序前：" + arrayToString(arr));

        // 这里减1，是控制每轮比较的次数
        for (int x = 0; x < arr.length - 1; x++) {
            // -1是为了避免索引越界，-x是为了调高比较效率
            for (int i = 0; i < arr.length - 1 - x; i++) {
                if (arr[i] > arr[i + 1]) {
                    int temp = arr[i];
                    arr[i] = arr[i + 1];
                    arr[i + 1] = temp;
                }
            }
        }
        System.out.println("排序后：" + arrayToString(arr));

    }

    //把数组中的元素按照指定的规则组成一个字符串：[元素1, 元素2, ...]
    public static String arrayToString(int[] arr) {
        //StringBuilder类也代表可变字符串对象。实际上，StringBuilder和StringBuffer基本相似，两个类的构造器和方法也基本相同。不同的是：StringBuffer是线程安全的，而StringBuilder则没有实现线程安全功能，所以性能略高。
        StringBuilder sb = new StringBuilder();
        sb.append("[");
        for (int i = 0; i < arr.length; i++) {
            if (i == arr.length - 1) {
                sb.append(arr[i]);
            } else {
                sb.append(arr[i]).append(", ");
            }
        }
        sb.append("]");
        String s = sb.toString();
        return s;
    }
}
```

### 1.7 Arrays

* Arrays的常用方法

  | 方法名                                     | 说明                               |
  | ------------------------------------------ | ---------------------------------- |
  | public static String **toString(int[] a)** | 返回指定数组的内容的字符串表示形式 |
  | public static void **sort(int[] a)**       | 按照数字顺序排列指定的数组         |

* 工具类设计思想

  1、构造方法用 private 修饰

  2、成员用 public static 修饰

## 2. 时间日期类

### 2.1 Date类

- Date类概述

  ​	Date 代表了一个特定的时间，精确到毫秒

- Date类构造方法

  | 方法名                 | 说明                                                         |
  | ---------------------- | ------------------------------------------------------------ |
  | public Date()          | 分配一个 Date对象，并初始化，以便它代表它被分配的时间，精确到毫秒 |
  | public Date(long date) | 分配一个 Date对象，并将其初始化为表示从标准基准时间起指定的毫秒数 |

- 示例代码

  ```java
  public class DateDemo01 {
      public static void main(String[] args) {
          //public Date()：分配一个 Date对象，并初始化，以便它代表它被分配的时间，精确到毫秒
          Date d1 = new Date();
          System.out.println(d1);
  
          //public Date(long date)：分配一个 Date对象，并将其初始化为表示从标准基准时间起指定的毫秒数
          long date = 1000*60*60;
          Date d2 = new Date(date);
          System.out.println(d2);
      }
  }
  ```

### 2.2 Date类常用方法

- 常用方法

  | 方法名                         | 说明                                                  |
  | ------------------------------ | ----------------------------------------------------- |
  | public long getTime()          | 获取的是日期对象从1970年1月1日 00:00:00到现在的毫秒值 |
  | public void setTime(long time) | 设置时间，给的是毫秒值                                |

- 示例代码

  ```java
  public class DateDemo02 {
      public static void main(String[] args) {
          //创建日期对象
          Date d = new Date();
  
          //public long getTime():获取的是日期对象从1970年1月1日 00:00:00到现在的毫秒值
  //        System.out.println(d.getTime());
  //        System.out.println(d.getTime() * 1.0 / 1000 / 60 / 60 / 24 / 365 + "年");
  
          //public void setTime(long time):设置时间，给的是毫秒值
  //        long time = 1000*60*60;
          long time = System.currentTimeMillis();
          d.setTime(time);
  
          System.out.println(d);
      }
  }
  ```

### 2.3 SimpleDateFormat类

- SimpleDateFormat类概述

  ​	SimpleDateFormat是一个具体的类，用于以区域设置敏感的方式格式化和解析日期。

  ​	我们重点学习日期格式化和解析

- SimpleDateFormat类构造方法

  | 方法名                                  | 说明                                                   |
  | --------------------------------------- | ------------------------------------------------------ |
  | public   SimpleDateFormat()             | 构造一个SimpleDateFormat，使用默认模式和日期格式       |
  | public SimpleDateFormat(String pattern) | 构造一个SimpleDateFormat使用给定的模式和默认的日期格式 |

- SimpleDateFormat类的常用方法

  - 格式化(从Date到String)
    - public final String format(Date date)：将日期格式化成日期/时间字符串
  - 解析(从String到Date)
    - public Date parse(String source)：从给定字符串的开始解析文本以生成日期

- 示例代码

  ```java
  public class SimpleDateFormatDemo {
      public static void main(String[] args) throws ParseException {
          //格式化：从 Date 到 String
          Date d = new Date();
  //        SimpleDateFormat sdf = new SimpleDateFormat();
          SimpleDateFormat sdf = new SimpleDateFormat("yyyy年MM月dd日 HH:mm:ss");
          String s = sdf.format(d);
          System.out.println(s);
          System.out.println("--------");
  
          //从 String 到 Date
          String ss = "2048-08-09 11:11:11";
          //ParseException
          SimpleDateFormat sdf2 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
          Date dd = sdf2.parse(ss);
          System.out.println(dd);
      }
  }
  ```

### 2.4 日期工具类案例

- 案例需求

  ​	定义一个日期工具类(DateUtils)，包含两个方法：把日期转换为指定格式的字符串；把字符串解析为指定格式的日期，然后定义一个测试类(DateDemo)，测试日期工具类的方法

- 代码实现

  - 工具类

  ```java
  public class DateUtils {
      private DateUtils() {}
  
      /*
          把日期转为指定格式的字符串
          返回值类型：String
          参数：Date date, String format
       */
      public static String dateToString(Date date, String format) {
          SimpleDateFormat sdf = new SimpleDateFormat(format);
          String s = sdf.format(date);
          return s;
      }
  
  
      /*
          把字符串解析为指定格式的日期
          返回值类型：Date
          参数：String s, String format
       */
      public static Date stringToDate(String s, String format) throws ParseException {
          SimpleDateFormat sdf = new SimpleDateFormat(format);
          Date d = sdf.parse(s);
          return d;
      }
  
  }
  ```

  - 测试类

  ```java
  public class DateDemo {
      public static void main(String[] args) throws ParseException {
          //创建日期对象
          Date d = new Date();
  
          String s1 = DateUtils.dateToString(d, "yyyy年MM月dd日 HH:mm:ss");
          System.out.println(s1);
  
          String s2 = DateUtils.dateToString(d, "yyyy年MM月dd日");
          System.out.println(s2);
  
          String s3 = DateUtils.dateToString(d, "HH:mm:ss");
          System.out.println(s3);
          System.out.println("--------");
  
          String s = "2048-08-09 12:12:12";
          Date dd = DateUtils.stringToDate(s, "yyyy-MM-dd HH:mm:ss");
          System.out.println(dd);
      }
  }
  ```

### 2.5 Calendar类

- Calendar类概述

  ​	Calendar 为特定瞬间与一组日历字段之间的转换提供了一些方法，并为操作日历字段提供了一些方法

  ​	Calendar 提供了一个类方法 getInstance 用于获取这种类型的一般有用的对象。

  ​	该方法返回一个Calendar 对象。

  ​	其日历字段已使用当前日期和时间初始化：Calendar rightNow = Calendar.getInstance();

- Calendar类常用方法

  | 方法名                                             | 说明                                                   |
  | -------------------------------------------------- | ------------------------------------------------------ |
  | public int   get(int field)                        | 返回给定日历字段的值                                   |
  | public abstract void add(int   field, int amount)  | 根据日历的规则，将指定的时间量添加或减去给定的日历字段 |
  | public final void set(int year,int month,int date) | 设置当前日历的年月日                                   |

- 示例代码

  ```java
  public class CalendarDemo {
      public static void main(String[] args) {
          //获取日历类对象
          Calendar c = Calendar.getInstance();
  
          //public int get(int field):返回给定日历字段的值
          int year = c.get(Calendar.YEAR);
          int month = c.get(Calendar.MONTH) + 1;
          int date = c.get(Calendar.DATE);
          System.out.println(year + "年" + month + "月" + date + "日");
  
          //public abstract void add(int field, int amount):根据日历的规则，将指定的时间量添加或减去给定的日历字段
          //需求1:3年前的今天
  //        c.add(Calendar.YEAR,-3);
  //        year = c.get(Calendar.YEAR);
  //        month = c.get(Calendar.MONTH) + 1;
  //        date = c.get(Calendar.DATE);
  //        System.out.println(year + "年" + month + "月" + date + "日");
  
          //需求2:10年后的10天前
  //        c.add(Calendar.YEAR,10);
  //        c.add(Calendar.DATE,-10);
  //        year = c.get(Calendar.YEAR);
  //        month = c.get(Calendar.MONTH) + 1;
  //        date = c.get(Calendar.DATE);
  //        System.out.println(year + "年" + month + "月" + date + "日");
  
          //public final void set(int year,int month,int date):设置当前日历的年月日
          c.set(2050,10,10);
          year = c.get(Calendar.YEAR);
          month = c.get(Calendar.MONTH) + 1;
          date = c.get(Calendar.DATE);
          System.out.println(year + "年" + month + "月" + date + "日");
  
      }
  }
  ```

#### 任意一年的二月有多少天

- 代码实现

  ```java
  public class CalendarTest {
      public static void main(String[] args) {
          //键盘录入任意的年份
          Scanner sc = new Scanner(System.in);
          System.out.println("请输入年：");
          int year = sc.nextInt();
  
          //设置日历对象的年、月、日
          Calendar c = Calendar.getInstance();
          c.set(year, 2, 1);
  
          //3月1日往前推一天，就是2月的最后一天
          c.add(Calendar.DATE, -1);
  
          //获取这一天输出即可
          int date = c.get(Calendar.DATE);
          System.out.println(year + "年的2月份有" + date + "天");
      }
  }
  ```

### 2.6  Random类

* 概述：

  * Random类似Scanner，也是Java提供好的API，内部提供了产生随机数的功能
    * API后续课程详细讲解，现在可以简单理解为Java已经写好的代码

* 使用步骤：

  1. ==**导入包**==

     import java.util.Random;

  2. ==**创建对象**==

     Random r = new Random();

  3. ==**产生随机数**==

     int num = r.nextInt(10);

     解释： 10代表的是一个范围，**如果括号写10，产生的随机数就是0-9**，括号写20，参数的随机数则是0-19

* 示例代码：

```java
import java.util.Random;
public class RandomDemo {
	public static void main(String[] args) {
		//创建对象
		Random r = new Random();
		//用循环获取10个随机数
		for(int i=0; i<10; i++) {
			//获取随机数
			int number = r.nextInt(10);
			System.out.println("number:" + number);
		}
		//需求：获取一个1-100之间的随机数
		int x = r.nextInt(100) + 1;
		System.out.println(x);
	}
}
// 'a' + 1 = 98;
for(int i='a';i<='z';i++){
    System.out.println((char)i);
}
```

#### Random练习-猜数字（应用）

* 需求：

  程序自动生成一个1-100之间的数字，使用程序实现猜出这个数字是多少？

  当猜错的时候根据不同情况给出相应的提示

  A. 如果猜的数字比真实数字大，提示你猜的数据大了

  B. 如果猜的数字比真实数字小，提示你猜的数据小了

  C. 如果猜的数字与真实数字相等，提示恭喜你猜中了

* 示例代码：

```java
import java.util.Random;
import java.util.Scanner;

public class RandomTest {
	public static void main(String[] args) {
		//要完成猜数字的游戏，首先需要有一个要猜的数字，使用随机数生成该数字，范围1到100
		Random r = new Random();
		int number = r.nextInt(100) + 1;
		
		while(true) {
			//使用程序实现猜数字，每次均要输入猜测的数字值，需要使用键盘录入实现
			Scanner sc = new Scanner(System.in);
			
			System.out.println("请输入你要猜的数字：");
			int guessNumber = sc.nextInt();
			
			//比较输入的数字和系统产生的数据，需要使用分支语句。
             //这里使用if..else..if..格式，根据不同情况进行猜测结果显示
			if(guessNumber > number) {
				System.out.println("你猜的数字" + guessNumber + "大了");
			} else if(guessNumber < number) {
				System.out.println("你猜的数字" + guessNumber + "小了");
			} else {
				System.out.println("恭喜你猜中了");
				break;
			}
		}
		
	}
}
```

