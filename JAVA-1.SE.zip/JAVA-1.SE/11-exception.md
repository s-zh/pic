## 3.异常

### 3.1 异常

- 异常的概述

  ​	==**异常**==：就是程序**在运行时**出现了不正常的情况

- 异常的体系结构

  ​	![01-c](https://gitee.com/mrth4869/pic/raw/master/20210801203332.png)

==由于Error没法处理，**重点关注Exception**：包括**编译异常**和**运行异常**==

### 3.2 JVM默认处理异常的方式

- 如果程序出现了问题，我们没有做任何处理，最终**JVM 会做默认的处理**，处理方式有如下两个步骤：

- **1.异常的名称，错误原因及异常出现的位置等信息输出在了控制台**
- **2.程序停止执行**

### 3.3 ==try-catch方式处理异常==

- 定义格式

  ```java
  try {
  	可能出现异常的代码;
  } catch(异常类名 变量名) {
  	异常的处理代码;
  } catch(异常类名 变量名) {
  	异常的处理代码;
  }
  ```

- 执行流程

  - **程序从 try 里面的代码开始执行**
  - **出现异常，就会跳转到对应的 catch 里面去执行**
  - **执行完毕之后，程序还可以继续往下执行**

- 示例代码

  ```java
  public class ExceptionDemo01 {
      public static void main(String[] args) {
          System.out.println("开始");
          method();
          System.out.println("结束");
      }
  
      public static void method() {
          try {
              int[] arr = {1, 2, 3};
              System.out.println(arr[3]);
              System.out.println("这里能够访问到吗?");
          } catch (ArrayIndexOutOfBoundsException e) {
  //            System.out.println("你访问的数组索引不存在，请回去修改为正确的索引");
              e.printStackTrace();
          }
      }
  }
  ```

### 3.4 Throwable类中的成员方法

- 常用方法

  | 方法名                            | 说明                              |
  | --------------------------------- | --------------------------------- |
  | public String **getMessage()**    | 返回此 throwable 的详细消息字符串 |
  | public String **toString()**      | 返回此可抛出的简短描述            |
  | public void **printStackTrace()** | 把异常的错误信息输出在控制台      |

- 示例代码

  ```java
  public class ExceptionDemo02 {
      public static void main(String[] args) {
          System.out.println("开始");
          method();
          System.out.println("结束");
      }
  
      public static void method() {
          try {
              int[] arr = {1, 2, 3};
              System.out.println(arr[3]); //new ArrayIndexOutOfBoundsException();
              System.out.println("这里能够访问到吗");
          } catch (ArrayIndexOutOfBoundsException e) { //new ArrayIndexOutOfBoundsException();
  //            e.printStackTrace();
  
              //public String getMessage():返回此 throwable 的详细消息字符串
  //            System.out.println(e.getMessage());
              //Index 3 out of bounds for length 3
  
              //public String toString():返回此可抛出的简短描述
  //            System.out.println(e.toString());
              //java.lang.ArrayIndexOutOfBoundsException: Index 3 out of bounds for length 3
  
              //public void printStackTrace():把异常的错误信息输出在控制台
              e.printStackTrace();
  //            java.lang.ArrayIndexOutOfBoundsException: Index 3 out of bounds for length 3
  //            at com.it_02.ExceptionDemo02.method(ExceptionDemo02.java:18)
  //            at com.it_02.ExceptionDemo02.main(ExceptionDemo02.java:11)
  
          }
      }
  }
  ```

### 3.5 编译时异常和运行时异常的区别

- 编译时异常
  - 都是Exception类及其子类
  - 必须显示处理，否则程序就会发生错误，无法通过编译

- 运行时异常
  - 都是RuntimeException类及其子类
  - 无需显示处理，也可以和编译时异常一样处理

### 3.6 ==throws方式处理异常==

- 定义格式

  ```java
  public void 方法() throws 异常类名 {
      
  }
  ```

- 示例代码

  ```java
  public class ExceptionDemo {
      public static void main(String[] args) {
          System.out.println("开始");
  //        method();
          try {
              method2();
          }catch (ParseException e) {
              e.printStackTrace();
          }
          System.out.println("结束");
      }
  
      //编译时异常
      public static void method2() throws ParseException {
          String s = "2048-08-09";
          SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
          Date d = sdf.parse(s);
          System.out.println(d);
      }
  
      //运行时异常
      public static void method() throws ArrayIndexOutOfBoundsException {
          int[] arr = {1, 2, 3};
          System.out.println(arr[3]);
      }
  }
  ```

- 注意事项

  - ==**这个throws格式是跟在方法的括号后面的**==
  - 编译时异常必须要进行处理，两种处理方案：try...catch …或者 throws，**如果采用 throws 这种方案，将来==谁调用谁处理，可以多次抛==，但如果谁都不解决，就会抛给JVM处理，==所以并不能解决问题，只能通过编译==**
  - 运行时异常可以不处理，出现问题后，需要我们回来修改代码

### 3.7 throws和throw的区别

- 位置区别：

  **throw用在函数(方法)体内，后面跟具体的异常对象**

  **throws用在函数方法上，后面跟一个或者多个异常类**

- 功能区别： 

  **throw**表示==**一定抛出了某种特定异常对象**==，执行到throw后，会跳转回调用者，并且调用者会接收到该异常

  **throws**表示==**可能抛出异常**==，并不一定会发生这些异常，调用者只是知道该方法可能出现的问题，可以预先给出处理方法

```java
class Test throws NullPointerException, ParseException{
    
}

public class ExceptionTest {
    public static void main(String[] args) {
        try{
            int num = 1+1;
            throw new NullPointerException("1+1报错");
        }catch (NullPointerException e){
            e.printStackTrace();
        }
    }
}
```

### 3.8自定义异常类（应用）

- ==**自定义异常类**==

  ```java
  public class ScoreException extends Exception {
  
      public ScoreException() {}
  
      public ScoreException(String message) {
          super(message);
      }
  
  }
  ```

- 老师类

  ```java
  public class Teacher {
      public void checkScore(int score) throws ScoreException {
          if(score<0 || score>100) {
  //            throw new ScoreException();
              throw new ScoreException("你给的分数有误，分数应该在0-100之间");
          } else {
              System.out.println("成绩正常");
          }
      }
  }
  ```

- 测试类

  ```java
  public class Demo {
      public static void main(String[] args) {
          Scanner sc = new Scanner(System.in);
          System.out.println("请输入分数：");
  
          int score = sc.nextInt();
  
          Teacher t = new Teacher();
          try {
              t.checkScore(score);
          } catch (ScoreException e) {
              e.printStackTrace();
          }
      }
  }
  ```

### 3.9 finally

==**不管是否出现异常, <u>finally代码块 一定会执行</u>**==

==**一般用于释放资源**==

```java
public void int test(){
	int i=1;
	try { return i;}             //本来应该在这里返回数据量i，但因为有必须执行的finally代码块且返回的数据量i在finally中被修改了，所以会自动用一个新变量j先保存数据量i，等到finally执行完再return j
	finally{ 
	i++;
	System.out.println(i);       //会输出i
	}
}
```

<center><b>注意：finally代码块不管如何，程序中一旦写上就必须执行</b></center>

